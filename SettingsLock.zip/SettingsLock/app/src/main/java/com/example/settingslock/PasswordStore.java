package com.example.settingslock;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.SystemClock;
import android.util.Base64;

import java.security.MessageDigest;
import java.security.SecureRandom;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/** Stores a salted PBKDF2 hash of the password and throttles wrong attempts. */
final class PasswordStore {
    private static final int ITERATIONS = 50000;
    private static final int MAX_FAILS = 5;
    private static final long BLOCK_MS = 30000;

    private static int fails;
    private static long blockedUntil;

    private PasswordStore() { }

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences("lock", Context.MODE_PRIVATE);
    }

    static boolean isSet(Context c) {
        return prefs(c).contains("hash");
    }

    static void set(Context c, String pw) {
        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);
        prefs(c).edit()
                .putString("salt", Base64.encodeToString(salt, Base64.NO_WRAP))
                .putString("hash", Base64.encodeToString(hash(pw, salt), Base64.NO_WRAP))
                .apply();
    }

    /** Milliseconds left until attempts are allowed again (0 = not blocked). */
    static long blockedMs() {
        return Math.max(0L, blockedUntil - SystemClock.elapsedRealtime());
    }

    static boolean check(Context c, String pw) {
        if (blockedMs() > 0) return false;
        SharedPreferences p = prefs(c);
        String s = p.getString("salt", null);
        String h = p.getString("hash", null);
        boolean ok = s != null && h != null && MessageDigest.isEqual(
                Base64.decode(h, Base64.NO_WRAP),
                hash(pw, Base64.decode(s, Base64.NO_WRAP)));
        if (ok) {
            fails = 0;
        } else if (++fails >= MAX_FAILS) {
            fails = 0;
            blockedUntil = SystemClock.elapsedRealtime() + BLOCK_MS;
        }
        return ok;
    }

    private static byte[] hash(String pw, byte[] salt) {
        try {
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1")
                    .generateSecret(new PBEKeySpec(pw.toCharArray(), salt, ITERATIONS, 256))
                    .getEncoded();
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }
}

package com.example.settingslock;

import android.app.admin.DeviceAdminReceiver;

/** Empty device-admin: its only job is to block uninstalling the app. */
public class AdminReceiver extends DeviceAdminReceiver {
}

package com.example.settingslock;

import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private TextView svc, adm;
    private EditText oldPw, newPw;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(20), dp(48), dp(20), dp(20));
        ScrollView sv = new ScrollView(this);
        sv.addView(col);
        setContentView(sv);

        text(col, 26).setText(R.string.app_name);
        svc = text(col, 16);
        button(col, R.string.open_acc,
                v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        adm = text(col, 16);
        button(col, R.string.enable_admin, v -> enableAdmin());
        oldPw = field(col, R.string.hint_old);
        newPw = field(col, R.string.hint_new);
        button(col, R.string.save, v -> save());
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void refresh() {
        boolean on = serviceEnabled();
        svc.setText(on ? R.string.svc_on : R.string.svc_off);
        svc.setTextColor(on ? 0xFF1B8A3A : 0xFFC62828);

        DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
        boolean admin = dpm != null
                && dpm.isAdminActive(new ComponentName(this, AdminReceiver.class));
        adm.setText(admin ? R.string.adm_on : R.string.adm_off);
        adm.setTextColor(admin ? 0xFF1B8A3A : 0xFFC62828);

        oldPw.setVisibility(PasswordStore.isSet(this) ? View.VISIBLE : View.GONE);
    }

    private boolean serviceEnabled() {
        String s = Settings.Secure.getString(getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (s == null) return false;
        ComponentName cn = new ComponentName(this, LockService.class);
        return s.contains(cn.flattenToString()) || s.contains(cn.flattenToShortString());
    }

    private void enableAdmin() {
        Intent i = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
        i.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN,
                new ComponentName(this, AdminReceiver.class));
        try {
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, e.toString(), Toast.LENGTH_LONG).show();
        }
    }

    private void save() {
        // Changing the password needs the current one, otherwise anyone could reset it here.
        if (PasswordStore.isSet(this)
                && !PasswordStore.check(this, oldPw.getText().toString())) {
            toast(R.string.bad_old);
            return;
        }
        String n = newPw.getText().toString();
        if (!n.matches("\\d{4,16}")) {
            toast(R.string.bad_new);
            return;
        }
        PasswordStore.set(this, n);
        oldPw.setText("");
        newPw.setText("");
        toast(R.string.saved);
        refresh();
    }

    private void toast(int res) {
        Toast.makeText(this, res, Toast.LENGTH_SHORT).show();
    }

    private TextView text(LinearLayout col, int sp) {
        TextView t = new TextView(this);
        t.setTextSize(sp);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, dp(16), 0, dp(8));
        col.addView(t);
        return t;
    }

    private Button button(LinearLayout col, int label, View.OnClickListener l) {
        Button x = new Button(this);
        x.setText(label);
        x.setOnClickListener(l);
        col.addView(x);
        return x;
    }

    private EditText field(LinearLayout col, int hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        col.addView(e);
        return e;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}

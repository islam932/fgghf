package com.example.settingslock;

import android.accessibilityservice.AccessibilityService;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.PixelFormat;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.inputmethod.InputMethodInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class LockService extends AccessibilityService {

    /** Packages that require the password. Add more package names here if you want. */
    private static final Set<String> LOCKED =
            new HashSet<>(Arrays.asList("com.android.settings"));

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final StringBuilder pin = new StringBuilder();
    private WindowManager wm;
    private View overlay;
    private TextView dots, msg;
    private boolean unlocked, shown;
    private String lastPkg = "";

    private final BroadcastReceiver screenReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            if (Intent.ACTION_SCREEN_OFF.equals(i.getAction())) {
                // Re-lock now, so the lock is already up when the screen wakes.
                unlocked = false;
                if (LOCKED.contains(lastPkg)) showLock();
            } else {
                checkForeground();
                handler.postDelayed(LockService.this::checkForeground, 400);
            }
        }
    };

    // ---------------------------------------------------------------- lifecycle

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        cleanup();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        buildOverlay(); // built and attached ahead of time, so showing it is as fast as possible

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT);
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        wm.addView(overlay, lp);

        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_SCREEN_OFF);
        f.addAction(Intent.ACTION_SCREEN_ON);
        f.addAction(Intent.ACTION_USER_PRESENT);
        registerReceiver(screenReceiver, f);

        checkForeground();
    }

    @Override
    public boolean onUnbind(Intent intent) {
        cleanup();
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        cleanup();
        super.onDestroy();
    }

    private void cleanup() {
        handler.removeCallbacksAndMessages(null);
        try { unregisterReceiver(screenReceiver); } catch (Exception ignored) { }
        try { if (overlay != null && wm != null) wm.removeView(overlay); } catch (Exception ignored) { }
        overlay = null;
        shown = false;
        unlocked = false;
    }

    // ---------------------------------------------------------------- detection

    @Override
    public void onAccessibilityEvent(AccessibilityEvent e) {
        if (e.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return;
        CharSequence p = e.getPackageName();
        if (p != null) onForeground(p.toString());
    }

    @Override
    public void onInterrupt() { }

    private void onForeground(String pkg) {
        if (overlay == null) return;
        if (LOCKED.contains(pkg)) {
            lastPkg = pkg;
            if (!unlocked) showLock();
        } else if (!ignorable(pkg)) {
            // The user left Settings for another app / the launcher: require the password next time.
            lastPkg = pkg;
            unlocked = false;
            hideLock();
        }
    }

    /** Re-reads which app is in front right now (used after screen on / unlock). */
    private void checkForeground() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;
        CharSequence p = root.getPackageName();
        root.recycle();
        if (p != null) onForeground(p.toString());
    }

    /** Windows that don't count as "leaving Settings": system UI, keyboards, this app. */
    private boolean ignorable(String pkg) {
        if (pkg.equals(getPackageName()) || pkg.equals("android")
                || pkg.equals("com.android.systemui")) {
            return true;
        }
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) {
            for (InputMethodInfo info : imm.getEnabledInputMethodList()) {
                if (pkg.equals(info.getPackageName())) return true;
            }
        }
        return false;
    }

    // ---------------------------------------------------------------- lock state

    private void showLock() {
        // Never lock when no password exists yet, otherwise you could lock yourself out.
        if (shown || overlay == null || !PasswordStore.isSet(this)) return;
        shown = true;
        pin.setLength(0);
        refresh("");
        overlay.setVisibility(View.VISIBLE);
    }

    private void hideLock() {
        if (!shown || overlay == null) return;
        shown = false;
        overlay.setVisibility(View.GONE);
    }

    private void key(String code) {
        if (code.equals("OK")) {
            submit();
            return;
        }
        if (code.equals("DEL")) {
            if (pin.length() > 0) pin.deleteCharAt(pin.length() - 1);
        } else if (pin.length() < 16) {
            pin.append(code);
        }
        refresh("");
    }

    private void submit() {
        long wait = PasswordStore.blockedMs();
        if (wait == 0 && PasswordStore.check(this, pin.toString())) {
            unlocked = true;
            hideLock();
            return;
        }
        pin.setLength(0);
        wait = PasswordStore.blockedMs();
        refresh(wait > 0 ? getString(R.string.try_later, wait / 1000 + 1)
                : getString(R.string.wrong));
    }

    private void refresh(String message) {
        StringBuilder s = new StringBuilder();
        for (int i = 0; i < pin.length(); i++) s.append("\u25CF ");
        dots.setText(s.length() == 0 ? " " : s.toString().trim());
        msg.setText(message);
    }

    // ---------------------------------------------------------------- overlay UI

    private void buildOverlay() {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER);
        col.setPadding(dp(24), dp(56), dp(24), dp(40));

        col.addView(label(getString(R.string.locked_title), 22, 0xFFFFFFFF));
        dots = label(" ", 28, 0xFFFFFFFF);
        dots.setMinHeight(dp(56));
        col.addView(dots);
        msg = label("", 14, 0xFFFF6B6B);
        col.addView(msg);

        String[][] rows = {{"1", "2", "3"}, {"4", "5", "6"}, {"7", "8", "9"}, {"DEL", "0", "OK"}};
        for (String[] r : rows) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            for (String code : r) addKey(row, code);
            col.addView(row, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }

        // Escape hatch so you are never stuck behind the lock (nav buttons may be covered).
        Button home = new Button(this);
        home.setText(R.string.go_home);
        home.setAllCaps(false);
        home.setTextColor(0xFFB8C2CC);
        home.setBackgroundColor(0x00000000);
        home.setOnClickListener(v -> {
            performGlobalAction(GLOBAL_ACTION_HOME);
            handler.postDelayed(this::checkForeground, 400);
        });
        col.addView(home);

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.setBackgroundColor(0xFF0F1318);
        sv.setClickable(true); // swallow every touch so nothing reaches Settings underneath
        sv.addView(col, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        sv.setVisibility(View.GONE);
        overlay = sv;
    }

    private void addKey(LinearLayout row, String code) {
        Button b = new Button(this);
        b.setText(code.equals("DEL") ? "\u2190" : code);
        b.setTextSize(24);
        b.setTextColor(0xFFFFFFFF);
        b.setAllCaps(false);
        b.setBackground(keyBackground());
        b.setOnClickListener(v -> key(code));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(64), 1f);
        lp.setMargins(dp(6), dp(6), dp(6), dp(6));
        row.addView(b, lp);
    }

    private TextView label(String text, int sp, int color) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(sp);
        v.setTextColor(color);
        v.setGravity(Gravity.CENTER);
        v.setPadding(0, dp(8), 0, dp(8));
        return v;
    }

    private Drawable keyBackground() {
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_pressed}, rounded(0xFF4A5560));
        s.addState(new int[]{}, rounded(0xFF2A313A));
        return s;
    }

    private GradientDrawable rounded(int color) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(16));
        return g;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
